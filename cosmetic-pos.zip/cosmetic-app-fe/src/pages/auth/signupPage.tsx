import SignUp from '@/components/auth/signup'

const SignupPage = () => {
  return <SignUp />
}

export default SignupPage
