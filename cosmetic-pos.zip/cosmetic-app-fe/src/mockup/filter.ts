export const filterDataMockupHome = [
  'All',
  'Skin care',
  'Body care',
  'Make up',
  'Hair care',
  'Personal care',
  'Tools & brushes'
]

export const filterDataMockupCategory = ['All', 'Deals', 'Trademark', 'New goods', 'Best sellers']
