import PasswordReset from '@/components/auth/ForgotPassword/passwordReset'

const PasswordResetPage = () => {
  return <PasswordReset />
}

export default PasswordResetPage
