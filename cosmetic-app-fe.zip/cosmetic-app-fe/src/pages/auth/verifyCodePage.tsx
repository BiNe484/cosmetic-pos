import VerifyCode from '@/components/auth/ForgotPassword/verifyCode'

const VerifyCodePage = () => {
  return <VerifyCode />
}

export default VerifyCodePage
