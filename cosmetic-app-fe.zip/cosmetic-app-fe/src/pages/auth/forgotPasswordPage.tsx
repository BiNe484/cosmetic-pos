import ForgotPassword from '@/components/auth/ForgotPassword/forgotpassword'

const ForgotPasswordPage = () => {
  return <ForgotPassword />
}

export default ForgotPasswordPage
